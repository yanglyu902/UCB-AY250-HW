This is a calculator for evaluating numerical expressions (in string format) both locally and on WolframAlpha. 

To download the package, use pip!

